//
//  DetailViewController.swift
//  Anjan-Project-1
//
//  Created by saikumar pola on 27/08/24.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var imageDetail: UIImageView!
    
    @IBOutlet weak var tyoeLabel: UILabel!
    
    @IBOutlet weak var yearLabel: UILabel!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var btnClick: UIButton!
    
    var varity: search? = nil
    var LikedArray: [String] = []
    let button = UIButton()
//    let text: String = button
    override func viewDidLoad() {
        super.viewDidLoad()
        btnClick = UIButton(type: .custom)
        title = varity?.Title
        if let varity = self.varity {
            if let Url = NSURL(string: varity.Poster) {
                URLSession.shared.dataTask(with: Url as URL) { (data, response, error) in
                    guard let imageData = data else {return}
                    DispatchQueue.main.async {
                        self.imageDetail.image = UIImage(data: imageData)
                    }
                }.resume()
            }
            self.tyoeLabel.text = varity.Type
            self.yearLabel.text = varity.Year
            self.titleLabel.text = varity.Title
            imageDetail.layer.shadowColor = UIColor.black.cgColor
            imageDetail.layer.shadowOffset = CGSize(width: 0, height: 2) // Adjust the offset as needed
            imageDetail.layer.shadowOpacity = 1 // Adjust opacity (0.0 to 1.0)
            imageDetail.layer.shadowRadius = 4 // Adjust blur radius
            
        }
    }
    
    @IBAction func actionBtn(_ sender: UIButton) {
        print("Button pressed")
        sender.imageView?.contentMode = .scaleAspectFit
        sender.clipsToBounds = true
        sender.setTitle("", for: .normal)
        
        LikedArray.append(UserDefaults.standard.string(forKey: "MovieName") ?? "")
        print(LikedArray)
        if let normalLikeImage = UIImage(systemName: "heart.fill")?.withRenderingMode(.alwaysOriginal),let likeImage = UIImage(systemName: "heart")?.withRenderingMode(.alwaysOriginal) {
            if sender.tag == 0 {
                print("Setting like image")
                sender.setImage(likeImage, for: .normal)
                sender.tag = 1
            } else {
                print("Setting normal like image")
                sender.setImage(normalLikeImage, for: .normal)
                sender.tag = 0
                UserDefaults.standard.set(titleLabel.text!,forKey: "MovieName")
                UserDefaults.standard.synchronize()
                let alert = UIAlertController(title: "Saving", message: "added to watch list", preferredStyle: .alert)
                let okButton = UIAlertAction(title: "OK", style: .default) { (action) in
                    print("added to favourite list")
                }
                alert.addAction(okButton)
                present(alert, animated: true,completion: nil)
            }
            
        } else {
            print("Error: Image not found")
        }
    }

}

//{
//    if sender.tag == 0 {
//        print("Setting like image")
//        sender.setImage(likeImage, for: .normal)
//        sender.tag = 1
//    } else {
//        print("Setting normal like image")
//        sender.setImage(normalLikeImage, for: .normal)
//        sender.tag = 0
//        UserDefaults.standard.set(titleLabel.text!,forKey: "MovieName")
//        UserDefaults.standard.synchronize()
//        let alert = UIAlertController(title: "Saving", message: "added to watch list", preferredStyle: .alert)
//        let okButton = UIAlertAction(title: "OK", style: .default) { (action) in
//            print("added to favourite list")
//        }
//        alert.addAction(okButton)
//        present(alert, animated: true,completion: nil)
//    }
//    
//}
