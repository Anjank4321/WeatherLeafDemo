//
//  ViewController.swift
//  Anjan-Project-1
//
//  Created by saikumar pola on 27/08/24.
//

import UIKit
import Foundation

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,UISearchBarDelegate {
    
    
    @IBOutlet weak var searchEngine: UISearchBar!
    
    @IBOutlet weak var tableViewMovie: UITableView!
    
    private var movieeViewModel : MovieViewModel!
    
    let searchBarr = UISearchBar()
    var movieName: String? = ""
    var varity: MovieInfo? = nil
    var items: [search] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        searchEngine.autocorrectionType = .no
        searchEngine.placeholder = "search"
        self.searchEngine.delegate = self
        self.tableViewMovie.delegate = self
        self.tableViewMovie.dataSource = self
        UserDefaults.standard.removeObject(forKey: "search")
        UserDefaults.standard.synchronize()
        callToViewModelForUIUpdate(inputS: "")
    }
    func callToViewModelForUIUpdate(inputS: String){
        
        self.movieeViewModel = MovieViewModel()
        self.movieeViewModel.searchString = inputS
        self.movieeViewModel.bindEmployeeViewModelToController = {
            self.updateDataSource()
        }
    }
    
    func updateDataSource(){
        self.items = self.movieeViewModel.movieData.Search
        
        DispatchQueue.main.async {
            self.tableViewMovie.dataSource = self
            self.tableViewMovie.reloadData()
        }
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        // Resign the search bar's first responder status
        searchBar.resignFirstResponder()
        // Check if the text is not nil
        if let localString = searchBar.text {
            // Debugging print statement to check the value of localString
            print("Search Bar Text: \(localString)")
            
            // Convert the string to lowercase
            movieName = localString.lowercased()
            
            // Debugging print statement to check the value of movieName
            print("Movie Name: \(String(describing: movieName!))")
            UserDefaults.standard.setValue(movieName!, forKey: "search")
            UserDefaults.standard.synchronize()
            callToViewModelForUIUpdate(inputS: "")
        } else {
            // Handle the case where searchBar.text is nil
            print("Search Bar text is nil")
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? TableCell
        let item = self.items[indexPath.row]
        cell?.nameLabel.text  = item.Title
        if let Url = NSURL(string: item.Poster) {
            URLSession.shared.dataTask(with: Url as URL) { (data, response, error) in
                guard let imageData = data else {return}
                
                DispatchQueue.main.async {
                    cell?.movieImage?.image = UIImage(data: imageData)
                }
                
            }.resume()
        }
        cell?.desLabel.text = item.Year
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let variety = self.items[indexPath.row]
        self.performSegue(withIdentifier: "navigateToD", sender: variety)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? DetailViewController, let varity = sender as? search {
            destination.varity = varity
        }
    }
    
    @IBAction func likeButtonTapped(_ sender: Any) {
        performSegue(withIdentifier: "navigateToSafe", sender: nil)
    }
    
    
}


