//
//  MovieVIewModel.swift
//  Anjan-Project-1
//
//  Created by saikumar pola on 29/08/24.
//

import Foundation

class MovieViewModel: NSObject {
    
    private var apiService : APIService!
    private(set) var movieData : MovieInfo! {
        didSet {
            self.bindEmployeeViewModelToController()
        }
    }
    var searchString:String?
    var bindEmployeeViewModelToController : (() -> ()) = {}
    
    override init() {
        super.init()
        self.apiService =  APIService()
        callFuncToGetMovies()
    }
    func callFuncToGetMovies() {
        var movieSearch = UserDefaults.standard.value(forKey: "search") ?? ""
        UserDefaults.standard.removeObject(forKey: "search")
        UserDefaults.standard.synchronize()
        self.apiService.getItems(inputS: "\(movieSearch)"){ (movieData) in
            self.movieData = movieData
        }
    }
}
