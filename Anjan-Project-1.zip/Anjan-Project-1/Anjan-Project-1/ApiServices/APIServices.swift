//
//  ViewModelVC.swift
//  Anjan-Project-1
//
//  Created by saikumar pola on 29/08/24.
//
//
import Foundation
import UIKit

class APIService :  NSObject {
    private let session: URLSession
    
    init(session: URLSession = .shared) {
        self.session = session
    }
    
    func getItems(inputS: String, completion : @escaping (MovieInfo) -> ()){
        var emptyString = ""
        if inputS == "" {
            emptyString = "move"
        }else {
            emptyString = inputS
        }
        let sourcesURL = URL(string: "https://www.omdbapi.com/?apikey=64e5c48a&type=movie&s=\(emptyString)")!
        
        
        
        URLSession.shared.dataTask(with: sourcesURL) { (data, urlResponse, error) in
            if let data = data {
                
                let jsonDecoder = JSONDecoder()
                do {
                    let empData = try jsonDecoder.decode(MovieInfo.self, from: data)
                    completion(empData)
                }catch {
                    print(error.localizedDescription)
                }
            }
            
        }.resume()
    }
}

