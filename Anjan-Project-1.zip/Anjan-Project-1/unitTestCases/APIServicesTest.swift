//
//  APIServicesTest.swift
//  Anjan-Project-1Tests
//
//  Created by saikumar pola on 29/08/24.
//
/*
import XCTest
import Foundation
@testable import Anjan_Project_1

 class APIServicesTest: XCTestCase {
    var apiService: APIService!
//    var MockURLProtocol: MockURLProtocol!
    var session: URLSession!
    
    override class func setUp() {
        super.setUp()
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [MockURLProtocol.self]
        session = URLSession(configuration: config)
        apiService = APIService(session: session)
    }
    override func tearDown() {
        super.tearDown()
        apiService = nil
        session = nil
    }
    
    func testForPass() {
        XCTAssertTrue(true)
    }
    
    func testGetItemsSuccess() {
        let mockData = """
        "search": [
                {
                    "Title": "Mock Movie",
                    "Year": "2021",
                    "imdbID": "tt1234567",
                    "Type": "Movie",
                    "poster": "N/A",
}
],
"totalResults": "1",
"Response": "True"
}
""".data(using: .utf8)!
        
        MockURLProtocol.requestHandler = { request in
            let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!
            return (response, mockData)
            
        }
        
        let expectation = self.expectation(description: "Completion handler invoked")
        var movieInfo: MovieInfo?
        
        //when
        apiService.getItems(inputS: "mock") { info in
            movieInfo = info
            expectation.fulfill()
        }
        waitForExpectations(timeout: 1, handler: nil)
        
        //Then
    XCTAssertNotNil(movieInfo)
        XCTAssertEqual(movieInfo?.Search.first?.Title, "Mock Movie")
    }
   
}
*/
